/*

    This file is part of Emu-Pizza

    Emu-Pizza is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Emu-Pizza is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Emu-Pizza.  If not, see <http://www.gnu.org/licenses/>.

*/

#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <inttypes.h>
#include <time.h>
#include "cpu/z80.h"
#include "exercize_z80.h"

/* this exercizer uses Z80 CPU, so let's instanciate its state struct */
z80_state_t *z80_state;

/* entry point for cpudiag emulate */
void exercize_z80_start(uint8_t *rom, size_t size)
{
    uint16_t addr;
    time_t   ts;
    time_t   tc;

    /* sanity check */
    if (size + 0x0100 > Z80_MAX_MEMORY)
    {
        printf("this ROM can't fit into memory\n");
        return;
    }

    /* init 8080 */
    z80_state = z80_init(1); 
  
    /* reset */
    bzero(z80_state->memory, 65536);
 
    /* load ROM at 0x0100 address of system memory */
    memcpy(&z80_state->memory[0x0100], rom, size);

    /* init PC to 0x0100 */
    z80_state->pc = 0x0100;

    /* OUT */
    z80_state->memory[0] = 0xd3;
    z80_state->memory[1] = 0x00;

    /* put a RET on 0x0005 address */
    z80_state->memory[5] = 0xDB; 
    z80_state->memory[6] = 0x00; 
    z80_state->memory[7] = 0xC9; 

/*    uint64_t cyc = 0;
    uint8_t  *flags = (uint8_t *) &z80_state->flags;  */

    /* set start time */
    time(&ts);

    /* running stuff! */
    for (;;)
    {
/*
        if (z80_state->non_ciclare == 0)
            cyc++;

        if (cyc >= 6000000000)
            break;
*/
//          if (cyc == 5294192617 || cyc == 5294873813)
//              cyc++;

/*        if (0 && cyc > 5721000000 && cyc < 5726000000)
        printf("CYC: %" PRIu64 " PC:%04x SP:%04x OP:%02x:%02x:%02x:%02x - A:%02x B:%02x C:%02x D:%02x E:%02x H:%02x L:%02x IX:%04x IY:%04x F:%02x MEM:%02x MEM2:%02x\n", cyc, 
            z80_state->pc, z80_state->sp, 
            z80_state->memory[z80_state->pc], z80_state->memory[z80_state->pc+1], 
            z80_state->memory[z80_state->pc+2], z80_state->memory[z80_state->pc+3], 
            z80_state->a, z80_state->b, z80_state->c,
            z80_state->d, z80_state->e, z80_state->h, z80_state->l,
            *(z80_state->ix), *(z80_state->iy), *flags, z80_state->memory[*z80_state->hl], 
            z80_state->memory[*(z80_state->ix) + 1]);

        if (z80_state->memory[z80_state->pc] == 0xfd ||
            z80_state->memory[z80_state->pc] == 0xdd)
            cyc++;

        z80_state->non_ciclare = 0;
*/
/*
        if ((z80_state->memory[z80_state->pc] == 0xfd ||
            z80_state->memory[z80_state->pc] == 0xdd) &&
            (z80_state->memory[z80_state->pc+1] == 0xe1 || 
             z80_state->memory[z80_state->pc+1] == 0xe5))
            cyc++;

        if (z80_state->memory[z80_state->pc] == 0xdd && 
            (z80_state->memory[z80_state->pc+1] == 0x09 || 
             z80_state->memory[z80_state->pc+1] == 0x19 ||
             z80_state->memory[z80_state->pc+1] == 0x29 ||
             z80_state->memory[z80_state->pc+1] == 0x39 ||
             z80_state->memory[z80_state->pc+1] == 0x84 ||
             z80_state->memory[z80_state->pc+1] == 0x85))
            cyc++;

        if (z80_state->memory[z80_state->pc] == 0xfd &&
            (z80_state->memory[z80_state->pc+1] == 0x09 || 
             z80_state->memory[z80_state->pc+1] == 0x19 ||
             z80_state->memory[z80_state->pc+1] == 0x29 ||
             z80_state->memory[z80_state->pc+1] == 0x39 ||
             z80_state->memory[z80_state->pc+1] == 0x84 ||
             z80_state->memory[z80_state->pc+1] == 0x85))
            cyc++;
*/

        /* debug purposes */
//        z80_disassemble(z80_state->memory, z80_state->pc);

        /* override CALL instruction */
        if (z80_state->memory[z80_state->pc] == 0xCD)
        {
            addr = (uint16_t) z80_state->memory[z80_state->pc + 1] | \
                   (uint16_t) (z80_state->memory[z80_state->pc + 2] << 8);

            if (addr == 5)
            {
                if (z80_state->c == 9)
                {
                    time(&tc);
                    
                    // printf("\nPASSATI %d SECS\n", tc -ts);

                    uint16_t offset = (z80_state->d<<8) | (z80_state->e);
                    unsigned char *str = &z80_state->memory[offset];

                    while (*str != '$')
                         printf("%c", *str++); 
                }
                if (z80_state->c == 2) putchar((char) z80_state->e);
            }      
            else if (addr == 0)
                     break;
        }

        if (z80_run())
            break;

        if (z80_state->pc == 0x0000)
        {
            printf("PC = 0x0000 - EXIT\n");
            break;
        }
    }

    return; 
}
